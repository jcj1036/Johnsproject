/*
 * classes.cpp
 *
 *  Created on: Nov 13, 2019
 *      Author: johnj
 */

#include <iostream>
#include <iomanip>
#include <cmath>
#include <sstream>
#include <fstream>			// needed for file I/O
#include <cstdlib>			// needed for exit()
using namespace std;

struct Passenger
{
	  string name;
	  int credits;
	  Passenger *nextaddr;
};

Passenger *read_credits()
{
	ifstream inFile;

	inFile.open("seat_credits.txt");

	if (inFile.fail())
	{
		cout << "\nThe file did not successfully open... Program Terminated\n" << endl;
		exit (1);
	}

	Passenger *current, *head;

	current = new Passenger;
	head = current;

	do
	{
		getline(inFile, current->name);
		inFile >> current->credits; inFile.ignore();

		if (inFile.eof())
		{
			current->nextaddr = NULL;
			break;
		}
		else
		{
			current->nextaddr = new Passenger;
			current = current->nextaddr;
		}
	}
	while (true);

	inFile.close();

	return (head);
}

class vehicle
{
	protected:
		string color;
		string type;

	public:
		vehicle()
		{
			color = " ";
			type = " ";
		}

		void setVehicle(string c, string t)
		{
			color  = c;
			type = t;
		}

		string get_color()
		{
			return color;
		}
};

class sedan: virtual public vehicle
{
	private:
		bool fs, bs, bs2, ms;
		int vf, vb, vb2, vm;
		string rf, rb, rb2, rm;

	public:
		sedan(bool fss = true, bool bss = true, bool bss2 = true, bool mss = true, int vff = 5, int vbb = 2, int vbb2 = 2, int vmm = 1, string rff = "unassigned", string rbb = "unassigned", string rbb2 = "unassigned", string rmm = "unassigned")
		{
			fs = fss;
			bs = bss;
			bs2 = bss2;
			ms = mss;
			vf = vff;
			vb = vbb;
			vb2 = vbb2;
			vm = vmm;
			rf = rff;
			rb = rbb;
			rb2 = rbb2;
			rm = rmm;
		}

		void set_fs(bool fss, string rff)
		{
			fs = fss;
			rf = rff;
		}

		void set_bs(bool bss, string rbb)
		{
			bs = bss;
			rb = rbb;
		}

		void set_bs2(bool bss2, string rbb2)
		{
			bs2 = bss2;
			rb2 = rbb2;
		}

		void set_ms(bool mss, string rmm)
		{
			ms = mss;
			rm = rmm;
		}

		bool get_fs()
		{
			return fs;
		}

		bool get_bs()
		{
			return bs;
		}

		bool get_bs2()
		{
			return bs2;
		}

		bool get_ms()
		{
			return ms;
		}

		int get_vf()
		{
			return vf;
		}

		int get_vb()
		{

			return vb;
		}

		int get_vb2()
		{
			return vb2;
		}

		int get_vm()
		{
			return vm;
		}

		string get_rf()
		{
			return rf;
		}

		string get_rb()
		{
			return rb;
		}

		string get_rb2()
		{
			return rb2;
		}

		string get_rm()
		{
			return rm;
		}
};

class pickup: virtual public vehicle
{
	private:
		bool pa;
		int pv;
		string pr;

	public:
		pickup(bool s_ava = true, int s_val = 5, string p_res = "unassigned")
		{
			pa = s_ava;
			pv = s_val;
			pr = p_res;
		}

		void set_seat(bool s_ava, string p_res)
		{
			pa = s_ava;
			pr = p_res;
		}

		bool get_pa()
		{
			return pa;
		}

		int get_pv()
		{
			return pv;
		}

		string get_pr()
		{
			return pr;
		}
};

class compact: virtual public vehicle
{
	private:
		bool fc, bc, bc2;
		int vcf, vcb, vcb2;
		string rfc, rbc, rbc2;

	public:
		compact(bool fcc = true, bool bcc = true, bool bcc2 = true, int vccf = 5, int vccb = 3, int vccb2 = 3, string rffc = "unassigned", string rbbc = "unassigned", string rbbc2 = "unassigned")
		{
			fc = fcc;
			bc = bcc;
			bc2 = bcc2;
			vcf = vccf;
			vcb = vccb;
			vcb2 = vccb2;
			rfc = rffc;
			rbc = rbbc;
			rbc2 = rbbc2;
		}

		void set_fc(bool fcc, string rffc)
		{
			fc = fcc;
			rfc = rffc;
		}

		void set_bc(bool bcc, string rbbc)
		{
			bc = bcc;
			rbc = rbbc;
		}

		void set_bc2(bool bcc2, string rbbc2)
		{
			bc2 = bcc2;
			rbc2 = rbbc2;
		}

		bool get_fc()
		{
			return fc;
		}

		bool get_bc()
		{
			return bc;
		}

		bool get_bc2()
		{
			return bc2;
		}

		int get_vcf()
		{
			return vcf;
		}

		int get_vcb()
		{
			return vcb;
		}

		int get_vcb2()
		{
			return vcb2;
		}

		string get_rfc()
		{
			return rfc;
		}

		string get_rbc()
		{
			return rbc;
		}

		string get_rbc2()
		{
			return rbc2;
		}
};

Passenger *create(Passenger *head, pickup& p1, pickup& p2, pickup& p3, sedan& s1, sedan& s2, sedan& s3, compact& c1, compact& c2, compact& c3)
{
	string name_in;
	Passenger *tmp;
	bool found = false;
	bool found_seat = false;
	bool found_fs = false;
	bool found_bs = false;
	bool found_ms = false;
	bool exit = false;
	bool exit_seat = false;
	bool exit_whole = false;
	bool exit_done = false;
	int select;
	int cat_sel;
	int car, seat;
	string finished;

	while (exit_whole != true)
	{
			while (exit != true)
			{
				cout << "please enter your name: ";
				getline(cin, name_in);
				tmp = head;

				while (tmp != NULL)
				{
					if (name_in == tmp->name)
					{
						found = true;
						break;
					}
					tmp = tmp->nextaddr;
				}

				if (found == true)
				{
					cout << "You have " << tmp->credits << " seat credits." << endl;
					if (tmp->credits == 0)
					{
						cout << "You have 0 credits and must find your own transportation" << endl;
					}
					else {break;}
				}
				else if (found == false)
				{
					cout << "Name not found" << endl;
				}
			}
			found = false;

			while(exit_seat != true)
			{
				cout << "Select a seat by catagory[1] or specific[2]: ";
				cin >> select; cin.ignore();
				if (select == 1)
				{
					cout << "select a category: front seat[1], back seat[2], middle seat[3]" << endl;
					cin >> cat_sel; cin.ignore();
					if (cat_sel == 1)
					{
						for (int i = 1; i <= 9; i++)
						{
							if (tmp->credits < 5)
							{
								cout << "You do not have enough credits for a front seat" << endl;
								break;
							}
							switch(i)
							{
							case 1:
								if (p1.get_pa() == true)
								{
									p1.set_seat(false, name_in);
									tmp->credits -= 5;
									cout << "You are in p1 fs." << endl;
									found_fs = true;
								}
								break;
							case 2:
								if (p2.get_pa() == true)
								{
									p2.set_seat(false, name_in);
									tmp->credits -= 5;
									cout << "You are in p2 fs." << endl;
									found_fs = true;
								}
								break;
							case 3:
								if (p3.get_pa() == true)
								{
									p3.set_seat(false, name_in);
									tmp->credits -= 5;
									cout << "You are in p3 fs." << endl;
									found_fs = true;
								}
								break;
							case 4:
								if (s1.get_fs() == true)
								{
									s1.set_fs(false, name_in);
									tmp->credits -= 5;
									cout << "You are in s1 fs." << endl;
									found_fs = true;
								}
								break;
							case 5:
								if (s2.get_fs() == true)
								{
									s2.set_fs(false, name_in);
									tmp->credits -= 5;
									cout << "You are in s2 fs." << endl;
									found_fs = true;
								}
								break;
							case 6:
								if (s3.get_fs() == true)
								{
									s3.set_fs(false, name_in);
									tmp->credits -= 5;
									cout << "You are in s3 fs." << endl;
									found_fs = true;
								}
								break;
							case 7:
								if (c1.get_fc() == true)
								{
									c1.set_fc(false, name_in);
									tmp->credits -= 5;
									cout << "You are in c1 fs." << endl;
									found_fs = true;
								}
								break;
							case 8:
								if (c2.get_fc() == true)
								{
									c2.set_fc(false, name_in);
									tmp->credits -= 5;
									cout << "You are in c2 fs." << endl;
									found_fs = true;
								}
								break;
							case 9:
								if (c3.get_fc() == true)
								{
									c3.set_fc(false, name_in);
									tmp->credits -= 5;
									cout << "You are in c3 fs." << endl;
									found_fs = true;
								}
								break;
							default: cout << "error at fs case" << endl;
							}//switch fs
							if (found_fs == true)
							{
								found_seat = true;
								break;
							}
						}//for loop fs
					}//if sel fs
					if (cat_sel == 2)
					{
						for (int i = 1; i <= 12; i++)
						{
							switch(i)
							{
							case 1:
								if (c1.get_bc() == true)
								{
									if (tmp->credits < 3)
									{
										cout << "You do not have enough credits for a compact back seat" << endl;
										break;
									}
									c1.set_bc(false, name_in);
									tmp->credits -= 3;
									cout << "You are in c1 bs1." << endl;
									found_bs = true;
								}
								break;
							case 2:
								if (c1.get_bc2() == true)
								{
									if (tmp->credits < 3)
									{
										cout << "You do not have enough credits for a compact back seat" << endl;
										break;
									}
									c1.set_bc2(false, name_in);
									tmp->credits -= 3;
									cout << "You are in c1 bs2." << endl;
									found_bs = true;
								}
								break;
							case 3:
								if (c2.get_bc() == true)
								{
									if (tmp->credits < 3)
									{
										cout << "You do not have enough credits for a compact back seat" << endl;
										break;
									}
									c2.set_bc(false, name_in);
									tmp->credits -= 3;
									cout << "You are in c2 bs1." << endl;
									found_bs = true;
								}
								break;
							case 4:
								if (c2.get_bc2() == true)
								{
									if (tmp->credits < 3)
									{
										cout << "You do not have enough credits for a compact back seat" << endl;
										break;
									}
									c2.set_bc2(false, name_in);
									tmp->credits -= 3;
									cout << "You are in c2 bs2." << endl;
									found_bs = true;
								}
								break;
							case 5:
								if (c3.get_bc() == true)
								{
									if (tmp->credits < 3)
									{
										cout << "You do not have enough credits for a compact back seat" << endl;
										break;
									}
									c3.set_bc(false, name_in);
									tmp->credits -= 3;
									cout << "You are in c3 bs1." << endl;
									found_bs = true;
								}
								break;
							case 6:
								if (c3.get_bc2() == true)
								{
									if (tmp->credits < 3)
									{
										cout << "You do not have enough credits for a compact back seat" << endl;
										break;
									}
									c3.set_bc2(false, name_in);
									tmp->credits -= 3;
									cout << "You are in c3 bs2." << endl;
									found_bs = true;
								}
								break;
							case 7:
								if (s1.get_bs() == true)
								{
									if (tmp->credits < 2)
									{
										cout << "You do not have enough credits for a back seat" << endl;
										break;
									}
									s1.set_bs(false, name_in);
									tmp->credits -= 2;
									cout << "You are in s1 bs1." << endl;
									found_bs = true;
								}
								break;
							case 8:
								if (s1.get_bs2() == true)
								{
									if (tmp->credits < 2)
									{
										cout << "You do not have enough credits for a back seat" << endl;
										break;
									}
									s1.set_bs2(false, name_in);
									tmp->credits -= 2;
									cout << "You are in s1 bs2." << endl;
									found_bs = true;
								}
								break;
							case 9:
								if (s2.get_bs() == true)
								{
									if (tmp->credits < 2)
									{
										cout << "You do not have enough credits for a back seat" << endl;
										break;
									}
									s2.set_bs(false, name_in);
									tmp->credits -= 2;
									cout << "You are in s2 bs1." << endl;
									found_bs = true;
								}
								break;
							case 10:
								if (s2.get_bs2() == true)
								{
									if (tmp->credits < 2)
									{
										cout << "You do not have enough credits for a back seat" << endl;
										break;
									}
									s2.set_bs2(false, name_in);
									tmp->credits -= 2;
									cout << "You are in s2 bs2." << endl;
									found_bs = true;
								}
								break;
							case 11:
								if (s3.get_bs() == true)
								{
									if (tmp->credits < 2)
									{
										cout << "You do not have enough credits for a back seat" << endl;
										break;
									}
									s3.set_bs(false, name_in);
									tmp->credits -= 2;
									cout << "You are in s3 bs1." << endl;
									found_bs = true;
								}
								break;
							case 12:
								if (s3.get_bs2() == true)
								{
									if (tmp->credits < 2)
									{
										cout << "You do not have enough credits for a back seat" << endl;
										break;
									}
									s3.set_bs2(false, name_in);
									tmp->credits -= 2;
									cout << "You are in s3 bs2." << endl;
									found_bs = true;
								}
								break;
							default: cout << "error at bs case" << endl;
							}//switch bs
							if (found_bs == true)
							{
								found_seat = true;
								break;
							}
						}//for loop bs
					}//if sel bs
					if (cat_sel == 3)
					{
						for (int i = 1; i <= 3; i++)
						{
							switch(i)
							{
							case 1:
								if (s1.get_ms() == true)
								{
									s1.set_ms(false, name_in);
									tmp->credits -= 1;
									cout << "You are in s1 ms." << endl;
									found_ms = true;
								}
								break;
							case 2:
								if (s2.get_ms() == true)
								{
									s2.set_ms(false, name_in);
									tmp->credits -= 1;
									cout << "You are in s2 ms." << endl;
									found_ms = true;
								}
								break;
							case 3:
								if (s3.get_ms() == true)
								{
									s3.set_ms(false, name_in);
									tmp->credits -= 1;
									cout << "You are in s3 ms." << endl;
									found_ms = true;
								}
								break;
							default: cout << "error at ms case" << endl;
							}//switch ms
							if (found_ms == true)
							{
								found_seat = true;
								break;
							}
						}//for loop ms
					}//if sel ms
					if (cat_sel != 1 && cat_sel != 2 && cat_sel != 3)
					{
						cout << "invalid entry" << endl;
					}
				}//if sel by cat

				// select by seat ----------------------------------------------------

				else if (select == 2) {
							cout
									<< "Select vehicle: \n (1) Red Sedan\n (2) Green Sedan\n (3) Blue Sedan\n "
											"(4) Green Compact\n (5) Blue Compact\n (6) Yellow Compact\n "
											"(7) Purple Pickup\n (8) Yellow Pickup\n (9) Red Pickup"
									<< endl;
							cin >> car;
							cin.ignore();
							if (car == 1) {
								cout
										<< "Select seat: \n (1) Front seat\n (2) Back seat\n (3) Middle seat\n "
										<< endl;
								cin >> seat;
								cin.ignore();
								if (seat == 1) {
									if (s1.get_fs()) {
										if (tmp->credits < 5) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 5;
											s1.set_fs(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Front seat is taken... " << endl;
									}
								} else if (seat == 2) {
									if (s1.get_bs()) {
										if (tmp->credits < 2) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 2;
											s1.set_bs(false, tmp->name);
											found_seat = true;
										}
									} else if (s1.get_bs2()) {
										if (tmp->credits < 2) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 2;
											s1.set_bs2(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Both back seats are taken... " << endl;
									}
								} else if (seat == 3) {
									if (s1.get_ms()) {
										if (tmp->credits < 1) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 1;
											s1.set_ms(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Middle seat is taken... " << endl;
									}
								}
							}
							if (car == 2) {
								cout
										<< "Select seat: \n (1) Front seat\n (2) Back seat\n (3) Middle seat\n "
										<< endl;
								cin >> seat;
								cin.ignore();
								if (seat == 1) {
									if (s2.get_fs()) {
										if (tmp->credits < 5) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 5;
											s2.set_fs(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Front seat is taken... " << endl;
									}
								} else if (seat == 2) {
									if (s2.get_bs()) {
										if (tmp->credits < 2) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 2;
											s2.set_bs(false, tmp->name);
											found_seat = true;
										}
									} else if (s2.get_bs2()) {
										if (tmp->credits < 2) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 2;
											s2.set_bs2(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Both back seats are taken... " << endl;
									}
								} else if (seat == 3) {
									if (s2.get_ms()) {
										if (tmp->credits < 1) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 1;
											s2.set_ms(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Middle seat is taken... " << endl;
									}
								}

							}
							if (car == 3) {
								cout
										<< "Select seat: \n (1) Front seat\n (2) Back seat\n (3) Middle seat\n "
										<< endl;
								cin >> seat;
								cin.ignore();
								if (seat == 1) {
									if (s3.get_fs()) {
										if (tmp->credits < 5) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 5;
											s3.set_fs(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Front seat is taken... " << endl;
									}
								} else if (seat == 2) {
									if (s3.get_bs()) {
										if (tmp->credits < 2) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 2;
											s3.set_bs(false, tmp->name);
											found_seat = true;
										}
									} else if (s3.get_bs2()) {
										if (tmp->credits < 2) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 2;
											s3.set_bs2(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Both back seats are taken... " << endl;
									}
								} else if (seat == 3) {
									if (s3.get_ms()) {
										if (tmp->credits < 1) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 1;
											s3.set_ms(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Middle seat is taken... " << endl;
									}
								}
							} else if (car == 4) {
								cout << "Select seat: \n (1) Front seat\n (2) Back seat\n "
										<< endl;
								cin >> seat;
								cin.ignore();
								if (seat == 1) {
									if (c1.get_fc()) {
										if (tmp->credits < 5) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 5;
											c1.set_fc(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Front seat is taken... " << endl;
									}
								} else if (seat == 2) {
									if (c1.get_bc()) {
										if (tmp->credits < 3) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 3;
											c1.set_bc(false, tmp->name);
											found_seat = true;
										}
									} else if (c1.get_bc2()) {
										if (tmp->credits < 3) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 3;
											c1.set_bc2(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Both back seats are taken... " << endl;
									}
								}
							} else if (car == 5) {
								cout << "Select seat: \n (1) Front seat\n (2) Back seat\n "
										<< endl;
								cin >> seat;
								cin.ignore();
								if (seat == 1) {
									if (c2.get_fc()) {
										if (tmp->credits < 5) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 5;
											c2.set_fc(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Front seat is taken... " << endl;
									}
								} else if (seat == 2) {
									if (c2.get_bc()) {
										if (tmp->credits < 3) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 3;
											c2.set_bc(false, tmp->name);
											found_seat = true;
										}
									} else if (c2.get_bc2()) {
										if (tmp->credits < 3) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 3;
											c2.set_bc2(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Both back seats are taken... " << endl;
									}
								}
							} else if (car == 6) {
								cout << "Select seat: \n (1) Front seat\n (2) Back seat\n "
										<< endl;
								cin >> seat;
								cin.ignore();
								if (seat == 1) {
									if (c3.get_fc()) {
										if (tmp->credits < 5) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 5;
											c3.set_fc(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Front seat is taken... " << endl;
									}
								} else if (seat == 2) {
									if (c3.get_bc()) {
										if (tmp->credits < 3) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 3;
											c3.set_bc(false, tmp->name);
											found_seat = true;
										}
									} else if (c3.get_bc2()) {
										if (tmp->credits < 3) {
											cout
													<< "Insufficient amount of credits for that seat..."
													<< endl;
										} else {
											tmp->credits = tmp->credits - 3;
											c3.set_bc2(false, tmp->name);
											found_seat = true;
										}
									} else {
										cout << "Both back seats are taken... " << endl;
									}
								}
							} else if (car == 7) {
								cout << "Selected Pickup Front Seat..." << endl;
								if (p1.get_pa()) {
									if (tmp->credits < 5) {
										cout
												<< "Insufficient amount of credits for that seat..."
												<< endl;
									} else {
										tmp->credits = tmp->credits - 5;
										p1.set_seat(false, tmp->name);
										found_seat = true;
									}
								} else {
									cout << "Front seat is taken... " << endl;
								}
							} else if (car == 8) {
								cout << "Selected Pickup Front Seat..." << endl;
								if (p2.get_pa()) {
									if (tmp->credits < 5) {
										cout
												<< "Insufficient amount of credits for that seat..."
												<< endl;
									} else {
										tmp->credits = tmp->credits - 5;
										p2.set_seat(false, tmp->name);
										found_seat = true;
									}
								} else {
									cout << "Front seat is taken... " << endl;
								}
							} else if (car == 9) {
								cout << "Selected Pickup Front Seat..." << endl;
								if (p3.get_pa()) {
									if (tmp->credits < 5) {
										cout
												<< "Insufficient amount of credits for that seat..."
												<< endl;
									} else {
										tmp->credits = tmp->credits - 5;
										p3.set_seat(false, tmp->name);
										found_seat = true;
									}
								} else {
									cout << "Front seat is taken... " << endl;
								}
							}
						}

				// select by seat end------------------------------------------------

				if (found_seat == true)
				{
					found_seat = false;
					found_fs = false;
					found_bs = false;
					found_ms = false;
					break;
				}
				else{cout << "you did not get in a seat" << endl;}
			}//while seat sel
			while(exit_done != true){
				cout << "Finished? Y or N: "; cin >> finished; cin.ignore();
				if (finished == "Y"){exit_whole = true; break;}
				else if (finished == "N"){break;}
				else if (finished != "Y" && finished != "N"){cout << "invalid entry" << endl;}
			}
	}//while whole loop
	return (head);
}




void display(sedan s1, sedan s2, sedan s3, pickup p1, pickup p2, pickup p3, compact c1, compact c2, compact c3) {
	char X = 'X';
	cout << "Truck   Compact     Sedan" << endl;
	cout << "------   -------     -----" << endl;
	cout << "(-)" << "(";
	if (p1.get_pa() == false) {
		cout << X;
	} else {
		cout << p1.get_pv();
	}
	cout << ")" << "   " << "(-)" << "(";
	if (c1.get_fc() == false) {
		cout << X;
	} else {
		cout << c1.get_vcf();
	}
	cout << ")" << "     " << "(-)" << "(";
	if (s1.get_fs() == false) {
		cout << X;
	} else {
		cout << s1.get_vf();
	}
	cout << ")" << endl;
	cout << "         " << "(";
	if (c1.get_bc() == false) {
		cout << X;
	} else {
		cout << c1.get_vcb();
	}
	cout << ")" << "(";
	if (c1.get_bc2() == false) {
		cout << X;
	} else {
		cout << c1.get_vcb2();
	}
	cout << ")" << "     " << "(";
	if (s1.get_bs() == false) {
		cout << X;
	} else {
		cout << s1.get_vb();
	}
	cout << ")" << "(";
	if (s1.get_ms() == false) {
		cout << X;
	} else {
		cout << s1.get_vm();
	}
	cout << ")" << "(";
	if (s1.get_bs2() == false) {
		cout << X;
	} else {
		cout << s1.get_vb2();
	}
	cout << ")" << endl;

	cout << "(-)" << "(";
		if (p2.get_pa() == false) {
			cout << X;
		} else {
			cout << p2.get_pv();
		}
		cout << ")" << "   " << "(-)" << "(";
		if (c2.get_fc() == false) {
			cout << X;
		} else {
			cout << c2.get_vcf();
		}
		cout << ")" << "     " << "(-)" << "(";
		if (s2.get_fs() == false) {
			cout << X;
		} else {
			cout << s2.get_vf();
		}
		cout << ")" << endl;
		cout << "         " << "(";
		if (c2.get_bc() == false) {
			cout << X;
		} else {
			cout << c2.get_vcb();
		}
		cout << ")" << "(";
		if (c2.get_bc2() == false) {
			cout << X;
		} else {
			cout << c2.get_vcb2();
		}
		cout << ")" << "     " << "(";
		if (s2.get_bs() == false) {
			cout << X;
		} else {
			cout << s2.get_vb();
		}
		cout << ")" << "(";
		if (s2.get_ms() == false) {
			cout << X;
		} else {
			cout << s2.get_vm();
		}
		cout << ")" << "(";
		if (s2.get_bs2() == false) {
			cout << X;
		} else {
			cout << s2.get_vb2();
		}
		cout << ")" << endl;

		cout << "(-)" << "(";
			if (p3.get_pa() == false) {
				cout << X;
			} else {
				cout << p3.get_pv();
			}
			cout << ")" << "   " << "(-)" << "(";
			if (c3.get_fc() == false) {
				cout << X;
			} else {
				cout << c3.get_vcf();
			}
			cout << ")" << "     " << "(-)" << "(";
			if (s3.get_fs() == false) {
				cout << X;
			} else {
				cout << s3.get_vf();
			}
			cout << ")" << endl;
			cout << "         " << "(";
			if (c3.get_bc() == false) {
				cout << X;
			} else {
				cout << c3.get_vcb();
			}
			cout << ")" << "(";
			if (c3.get_bc2() == false) {
				cout << X;
			} else {
				cout << c3.get_vcb2();
			}
			cout << ")" << "     " << "(";
			if (s3.get_bs() == false) {
				cout << X;
			} else {
				cout << s3.get_vb();
			}
			cout << ")" << "(";
			if (s3.get_ms() == false) {
				cout << X;
			} else {
				cout << s3.get_vm();
			}
			cout << ")" << "(";
			if (s3.get_bs2() == false) {
				cout << X;
			} else {
				cout << s3.get_vb2();
			}
			cout << ")" << endl;
}

//Function to display linked list(playlist)
void display_roster(Passenger *head) {
	int cnt = 1;							//Variable to display a number next to each structure of a linked list

	Passenger *current = head;					//Point current pointer at head of roster

	cout << "Roster: " << endl;			//Output first line to roster
	cout << "       Names          Credits" << endl;

	while (current != NULL) {				//Output structure of each node until end of linked list is reached
		cout << right << setw(4) << cnt++ << ")  ";
		cout << left << setw(15) << current->name;
		cout << left << setw(5) << current->credits << endl;

		current = current -> nextaddr;		//Traverse current pointer to next node of linked list
	}

	return;
}

void reservations(pickup p1, pickup p2, pickup p3, sedan s1, sedan s2, sedan s3, compact c1, compact c2, compact c3)
{
	ofstream outfile("reservation.txt");
	if (outfile.fail())
	{
		cout << "\nThe file did not successfully open... Program Terminated\n" << endl;
		exit (1);
	}

	if(outfile.is_open())
	{
		outfile << "green pickup" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << p1.get_pr() << "\n";
		outfile << "\n";
		outfile << "purple pickup" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << p2.get_pr() << "\n";
		outfile << "\n";
		outfile << "red pickup" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << p3.get_pr() << "\n";
		outfile << "\n";
		outfile << "green compact" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << c1.get_rfc() << "\n";
		outfile << "back seat 1: " << c1.get_rbc() << "\n";
		outfile << "back seat 2: " << c1.get_rbc2() << "\n";
		outfile << "\n";
		outfile << "purple compact" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << c2.get_rfc() << "\n";
		outfile << "back seat 1: " << c2.get_rbc() << "\n";
		outfile << "back seat 2: " << c2.get_rbc2() << "\n";
		outfile << "\n";
		outfile << "red compact" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << c3.get_rfc() << "\n";
		outfile << "back seat 1: " << c3.get_rbc() << "\n";
		outfile << "back seat 2: " << c3.get_rbc2() << "\n";
		outfile << "\n";
		outfile << "green sedan" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << s1.get_rf() << "\n";
		outfile << "back seat 1: " << s1.get_rb() << "\n";
		outfile << "back seat 2: " << s1.get_rb2() << "\n";
		outfile << "middle seat: " << s1.get_rm() << "\n";
		outfile << "\n";
		outfile << "purple sedan" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << s2.get_rf() << "\n";
		outfile << "back seat 1: " << s2.get_rb() << "\n";
		outfile << "back seat 2: " << s2.get_rb2() << "\n";
		outfile << "middle seat: " << s2.get_rm() << "\n";
		outfile << "\n";
		outfile << "red sedan" << "\n";
		outfile << "-----------" << "\n";
		outfile << "front seat: " << s3.get_rf() << "\n";
		outfile << "back seat 1: " << s3.get_rb() << "\n";
		outfile << "back seat 2: " << s3.get_rb2() << "\n";
		outfile << "middle seat: " << s3.get_rm() << "\n";
		outfile << "\n";
		outfile.close();
	}

	cout << "green pickup" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << p1.get_pr() << endl;
	cout << endl;
	cout << "purple pickup" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << p2.get_pr() << endl;
	cout << endl;
	cout << "red pickup" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << p3.get_pr() << endl;
	cout << endl;
	cout << "green compact" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << c1.get_rfc() << endl;
	cout << "back seat 1: " << c1.get_rbc() << endl;
	cout << "back seat 2: " << c1.get_rbc2() << endl;
	cout << endl;
	cout << "purple compact" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << c2.get_rfc() << endl;
	cout << "back seat 1: " << c2.get_rbc() << endl;
	cout << "back seat 2: " << c2.get_rbc2() << endl;
	cout << endl;
	cout << "red compact" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << c3.get_rfc() << endl;
	cout << "back seat 1: " << c3.get_rbc() << endl;
	cout << "back seat 2: " << c3.get_rbc2() << endl;
	cout << endl;
	cout << "green sedan" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << s1.get_rf() << endl;
	cout << "back seat 1: " << s1.get_rb() << endl;
	cout << "back seat 2: " << s1.get_rb2() << endl;
	cout << "middle seat: " << s1.get_rm() << endl;
	cout << endl;
	cout << "purple sedan" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << s2.get_rf() << endl;
	cout << "back seat 1: " << s2.get_rb() << endl;
	cout << "back seat 2: " << s2.get_rb2() << endl;
	cout << "middle seat: " << s2.get_rm() << endl;
	cout << endl;
	cout << "red sedan" << endl;
	cout << "-----------" << endl;
	cout << "front seat: " << s3.get_rf() << endl;
	cout << "back seat 1: " << s3.get_rb() << endl;
	cout << "back seat 2: " << s3.get_rb2() << endl;
	cout << "middle seat: " << s3.get_rm() << endl;
	cout << endl;

	return;
}

void print(Passenger *head, sedan s1, sedan s2, sedan s3, compact c1,
		compact c2, compact c3, pickup p1, pickup p2, pickup p3) {
	int car;
	cout << "Select Vehicle to print : " << endl;
	cout
			<< "Select vehicle: \n (1) Red Sedan\n (2) Green Sedan\n (3) Blue Sedan\n "
					"(4) Green Compact\n (5) Blue Compact\n (6) Yellow Compact\n "
					"(7) Purple Pickup\n (8) Yellow Pickup\n (9) Red Pickup"
			<< endl;
	cin >> car;
	cin.ignore();

	if (car == 1) {
		ofstream outfile("red_sedan.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!s1.get_fs()) {
			outfile << s1.get_rf() << endl;
			cout << s1.get_rf() << endl;
		}
		if (!s1.get_bs()) {
			outfile << s1.get_rb() << endl;
			cout << s1.get_rb() << endl;
		}
		if (!s1.get_bs2()) {
			outfile << s1.get_rb2() << endl;
			cout << s1.get_rb2() << endl;
		}
		if (!s1.get_ms()) {
			outfile << s1.get_rm() << endl;
			cout << s1.get_rm() << endl;
		}
		if (s1.get_fs() && s1.get_bs() && s1.get_bs2() && s1.get_ms()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 2) {
		ofstream outfile("green_sedan.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!s2.get_fs()) {
			outfile << s2.get_rf() << endl;
			cout << s2.get_rf() << endl;
		}
		if (!s2.get_bs()) {
			outfile << s2.get_rb() << endl;
			cout << s2.get_rb() << endl;
		}
		if (!s2.get_bs2()) {
			outfile << s2.get_rb2() << endl;
			cout << s2.get_rb2() << endl;
		}
		if (!s2.get_ms()) {
			outfile << s2.get_rm() << endl;
			cout << s2.get_rm() << endl;
		}
		if (s2.get_fs() && s2.get_bs() && s2.get_bs2() && s2.get_ms()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 3) {
		ofstream outfile("blue_sedan.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!s3.get_fs()) {
			outfile << s3.get_rf() << endl;
			cout << s3.get_rf() << endl;
		}
		if (!s3.get_bs()) {
			outfile << s3.get_rb() << endl;
			cout << s3.get_rb() << endl;
		}
		if (!s3.get_bs2()) {
			outfile << s3.get_rb2() << endl;
			cout << s3.get_rb2() << endl;
		}
		if (!s3.get_ms()) {
			outfile << s3.get_rm() << endl;
			cout << s3.get_rm() << endl;
		}
		if (s3.get_fs() && s3.get_bs() && s3.get_bs2() && s3.get_ms()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 4) {
		ofstream outfile("green_compact.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!c1.get_fc()) {
			outfile << c1.get_rfc() << endl;
			cout << c1.get_rfc() << endl;
		}
		if (!c1.get_bc()) {
			outfile << c1.get_rbc() << endl;
			cout << c1.get_rbc() << endl;
		}
		if (!c1.get_bc2()) {
			outfile << c1.get_rbc2() << endl;
			cout << c1.get_rbc2() << endl;
		}
		if (c1.get_fc() && c1.get_bc() && c1.get_bc2()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 5) {
		ofstream outfile("blue_compact.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!c2.get_fc()) {
			outfile << c2.get_rfc() << endl;
			cout << c2.get_rfc() << endl;
		}
		if (!c2.get_bc()) {
			outfile << c2.get_rbc() << endl;
			cout << c2.get_rbc() << endl;
		}
		if (!c2.get_bc2()) {
			outfile << c2.get_rbc2() << endl;
			cout << c2.get_rbc2() << endl;
		}
		if (c2.get_fc() && c2.get_bc() && c2.get_bc2()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 6) {
		ofstream outfile("yellow_compact.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!c3.get_fc()) {
			outfile << c3.get_rfc() << endl;
			cout << c3.get_rfc() << endl;
		}
		if (!c3.get_bc()) {
			outfile << c3.get_rbc() << endl;
			cout << c3.get_rbc() << endl;
		}
		if (!c3.get_bc2()) {
			outfile << c3.get_rbc2() << endl;
			cout << c3.get_rbc2() << endl;
		}
		if (c3.get_fc() && c3.get_bc() && c3.get_bc2()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 7) {
		ofstream outfile("purple_pickup.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!p1.get_pa()) {
			outfile << p1.get_pr() << endl;
			cout << p1.get_pr() << endl;
		}
		if (p1.get_pa()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 8) {
		ofstream outfile("yellow_pickup.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!p2.get_pa()) {
			outfile << p2.get_pr() << endl;
			cout << p2.get_pr() << endl;
		}
		if (p2.get_pa()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	} else if (car == 9) {
		ofstream outfile("red_pickup.txt");
		if (outfile.fail()) {
			cout
					<< "\nThe file did not successfully open... Program Terminated\n"
					<< endl;
			exit(1);
		}
		if (!p3.get_pa()) {
			outfile << p3.get_pr() << endl;
			cout << p3.get_pr() << endl;
		}
		if (p3.get_pa()) {
			outfile << "No passengers in this vehicle" << endl;
			cout << "No passengers in this vehicle" << endl;
		}
	}

}

int main()
{
	sedan s1, s2, s3;
	compact c1, c2, c3;
	pickup p1, p2, p3;
	Passenger *roster;
	//instantiation of sedans
	s1.setVehicle("Red", "Sedan");
	s2.setVehicle("Green", "Sedan");
	s3.setVehicle("Blue", "Sedan");
	//instantiation of compacts
	c1.setVehicle("Green", "Compact");
	c2.setVehicle("Blue", "Compact");
	c3.setVehicle("Yellow", "Compact");
	//instantiation of pickups
	p1.setVehicle("Purple", "Pickup");
	p2.setVehicle("Yellow", "Pickup");
	p3.setVehicle("Red", "Pickup");

	//reads the file and returns a linked list of passengers stored as roster.
	roster = read_credits();
	//displays the roster linked list
	display_roster(roster);

	int input;
	do {
		//menu loops through until user chooses to exit
		cout << "Rowing Team Carpool Reservation System Menu..." << endl;
		cout
				<< " (1) - New Reservation\n (2) - Display Vehicle Diagram\n (3) - Modify a Reservation\n (4) - Delete a Reservation\n (5) - Print Vehicle Assignments\n (6) - Print Reservations (System Administrators Only)\n (0) - EXIT"
				<< endl;
		cout << "Please enter the number corresponding to your choice:" << endl;
		cin >> input;
		cin.ignore();
		if (input == 1) {			//if create
			create(roster, p1, p2, p3, s1, s2, s3, c1, c2, c3);
		} else if (input == 2) {			//if display
			display(s1, s2, s3, p1, p2, p3, c1, c2, c3);
		} else if (input == 3) {			//if modify
			modify(roster, p1, p2, p3, s1, s2, s3, c1, c2, c3);
		} else if (input == 4) {			//if delete
			Delete(roster, p1, p2, p3, s1, s2, s3, c1, c2, c3);
		} else if (input == 5) {			//if print
			print(roster, s1, s2, s3, c1, c2, c3, p1, p2, p3);
		} else if (input == 6) {			//if reservations
			reservations(p1, p2, p3, s1, s2, s3, c1, c2, c3);
		} else if (input == 0) {			//if EXIT
			cout << "Goodbye..." << endl;
			break;
		} else {

		}
	} while (true);

	return 0;
}

